﻿#------------------Variable avant suppression------------------
$Taille = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DeviceID -eq 'C:'} | Select-Object @{Name='Taille';Expression={($_.Size / 1GB).ToString('F2')}}

$Date = Get-Date -Format "f"

$FreeSpace = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DeviceID -eq 'C:'} | Select-Object @{Name='Espace libre';Expression={($_.FreeSpace / 1GB).ToString('F2')}}
 
#------------------Principal------------------
# Ici est mis la création du fichier (changeable car il faudrait des permissions admin après)

# En-dessous, il crée le dossier pour mettre le fichier.
New-Item -Name Résultat -Path C:\Users\*\Documents -ItemType Directory

# En-dessous, crée le fichier texte dans le dossier qu'on a crée.
New-Item -Name test.txt -Path C:\Users\*\Documents\Résultat

Add-Content -Path C:\Users\*\Documents\Résultat\test.txt -Value "

 (         (   (   (                *    (     
 )\ )      )\ ))\ ))\ )  *   )    (  `   )\ )  
(()/(   ( (()/(()/(()/(` )  /((   )\))( (()/(  
 /(_))  )\ /(_))(_))(_))( )(_))\ ((_)()\ /(_)) 
(_)) _ ((_|_))(_))(_)) (_(_()|(_)(_()((_|_))   
/ __| | | | _ \ _ \ _ \|_   _| __|  \/  | _ \  
\__ \ |_| |  _/  _/   /  | | | _|| |\/| |  _/  
|___/\___/|_| |_| |_|_\  |_| |___|_|  |_|_|    
                                               
Par matt2709

Date : $Date

-----------AVANT SUPPRESSION TEMP-----------

Taille du disque : $Taille

Espace libre dans le disque : $FreeSpace
"


# Suppression du contenue du dossier TEMP

Get-ChildItem C:\Users\*\AppData\Local\Temp\* | Remove-Item -Force -Recurse

# Actualisation

#------------------Variable après suppression------------------
$TailleA = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DeviceID -eq 'C:'} | Select-Object @{Name='Taille';Expression={($_.Size / 1GB).ToString('F2')}}


$FreeSpaceA = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DeviceID -eq 'C:'} | Select-Object @{Name='Espace libre';Expression={($_.FreeSpace / 1GB).ToString('F2')}}

Add-Content -Path C:\Users\*\Documents\Résultat\test.txt -Value "

-----------APRES SUPPRESSION TEMP-----------

Taille du disque : $TailleA

Espace libre dans le disque : $FreeSpaceA
"